# Quiz App

It is an Android app that consists of a quiz, with questions related to the flags of different countries.

The app consists of 3 screens. On the first screen, the user informs his name, before starting the quiz. The second screen displays the questions, which will change as the user answers one question and moves on to the next.


# Demo Video

If you want to see this app running, click on image below to take a look on a demo illustrated in a YouTube video:

https://drive.google.com/file/d/1s8CUUNuOE9Qj1QksCYYbkpeVXohUAEWd/view?usp=sharing
## Author

<a href="https://www.linkedin.com/in/sreeja-tirunamala/">
 <img style="border-radius: 50px;" src="https://avatars.githubusercontent.com/u/your-github-id?v=4" width="100px;" alt=""/>
 <br />
 <b>Sreeja Tirunamala</b></a>

Made with ❤️ by Sreeja Tirunamala 👋🏽

Contact me!

[![Linkedin Badge](https://img.shields.io/badge/LinkedIn-SreejaTirunamala-blue?style=flat-square&logo=Linkedin&logoColor=white](https://www.linkedin.com/in/sreeja-tirunamala-068540262)
[![Gmail Badge](https://img.shields.io/badge/sreeja.tirunamala@gmail.com-c14438?style=flat-square&logo=Gmail&logoColor=white&link=mailto:your-email@gmail.com)](mailto:your-email@gmail.com)